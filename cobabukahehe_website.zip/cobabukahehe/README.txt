COBABUKAHEHE — Website ulang tahun Kezia

ISI:
- index.html: website satu file, siap dibuka di browser atau diunggah ke hosting statis.
- Tema, teks, dua slot foto, dan musik dapat diedit lewat tombol ⚙ Edit.
- Tekan “Finalkan website” untuk menyembunyikan panel edit di browser yang sedang digunakan.
- Perubahan disimpan dalam localStorage browser, bukan otomatis ke server. Foto dan musik yang diunggah disimpan di browser tersebut.

PENTING:
- Simpan salinan foto dan file musik asli. Data browser bisa hilang jika data situs dihapus atau browser berganti.
- Untuk berbagi website ke orang lain, unggah index.html ke layanan hosting statis seperti GitHub Pages, Netlify, atau Cloudflare Pages.
- Domain gratis/subdomain harus didaftarkan sendiri pada layanan hosting. Nama “cobabukahehe” belum otomatis menjadi domain yang tersedia.
- Kalau ingin hasil final yang tidak bisa diedit oleh pengunjung, lakukan finalisasi lalu unggah. Namun tombol edit finalisasi hanya mengunci panel edit pada browser; ini bukan sistem keamanan server.
- Font Aquafina Script dimuat dari Google Fonts jika koneksi internet tersedia. “07nikumarufont” dipanggil sesuai nama font yang diminta; jika font itu tidak terpasang di perangkat, browser akan memakai font cadangan. Untuk tampilan persis, sediakan file font legal (.woff2/.ttf) dan pasang di CSS.
